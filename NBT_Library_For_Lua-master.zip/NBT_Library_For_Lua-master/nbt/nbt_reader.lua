--NBT reader

local M = {}
local NBT_Common = require("nbt.nbt_common")

local function readBig_Byte(reader)
  local unsignNum = string.byte(reader(1)) 
  local signedNum = ~(unsignNum - 1) & 0xFF 
  if math.floor(unsignNum / 2^7) % 2 == 1 then
    signedNum = -signedNum
  else
    signedNum = unsignNum
  end
  print(signedNum)
  return signedNum 
end

local function readBig_Short(reader)
  local unsignNum = string.byte(reader(1)) * 256 + 
                    string.byte(reader(1))
  local signedNum = ~(unsignNum - 1) & 0xFFFF  
  if math.floor(unsignNum / 2^15) % 2 == 1 then
    signedNum = -signedNum
  else
    signedNum = unsignNum
  end
  return signedNum 
end

local function readBig_Int(reader)
  local unsignNum = string.byte(reader(1)) * 16777216 +  
                    string.byte(reader(1)) * 65536 +
                    string.byte(reader(1)) * 256 +
                    string.byte(reader(1)) 
  local signedNum = ~(unsignNum - 1) & 0xFFFFFFFF 
  if math.floor(unsignNum / 2^31) % 2 == 1 then
    signedNum = -signedNum
  else
    signedNum = unsignNum
  end
  return signedNum  
end

local TAG_Short_read
local TAG_String_read
local TAG_Named_read
local TAG_Compound_read
local TAG_Byte_read
local TAG_Long_read
local TAG_Int_read
local TAG_List_read
local TAG_Double_read
local TAG_Float_read
local TAG_ByteArray_read

local tag_reader_list = {}

TAG_ByteArray_read = function(reader)
  local length = TAG_Int_read(reader)
  local data = {}
  
  for i=1,length do
    data[i] = readBig_Byte(reader)
  end
  
  return data
end

TAG_Double_read = function(reader)
  return NBT_Common.decodeDouble(reader(8))
end

TAG_Float_read = function(reader)
  return NBT_Common.decodeFloat(reader(4)) 
end

TAG_List_read = function(reader)
  local tagType = TAG_Byte_read(reader)
  local length = TAG_Int_read(reader)
  local data = {}
  local tag_reader = nil
  
  if tagType == NBT_Common.TAG_END then
    return {}
  end
  
  tag_reader = tag_reader_list[tagType]
  if tag_reader == nil then
    error(string.format("Unknown tag 0x%02X", tagType))
  end
  
  data.type = tagType
  data.len = length 
  for i=1,length do
    data[i] = {
      data = tag_reader(reader),
      type = tagType
    }
  end
  
  return data
end

TAG_Short_read = function(reader)
  return readBig_Short(reader)
end

TAG_Int_read = function(reader)
  return readBig_Int(reader)
end

TAG_Long_read = function(reader)
  return {
    high = string.byte(reader(1)) * 16777216 +  
           string.byte(reader(1)) * 65536 +
           string.byte(reader(1)) * 256 +
           string.byte(reader(1)), 
    low = string.byte(reader(1)) * 16777216 +  
          string.byte(reader(1)) * 65536 +
          string.byte(reader(1)) * 256 +
          string.byte(reader(1))
  }
end

TAG_String_read = function(reader)
  return reader(TAG_Short_read(reader))
end

TAG_Byte_read = function(reader)
  return string.byte(reader(1))
end

TAG_Compound_read = function(reader)
  local tagType, name, data = TAG_Named_read(reader)
  local tab = {}
  
  while tagType ~= NBT_Common.TAG_END do
    tab[name] = {
      data = data,
      type = tagType,
    }
    tagType, name, data = TAG_Named_read(reader)
  end
  
  return tab
end

TAG_Named_read = function(reader, expect)
  local tagType = TAG_Byte_read(reader)
  if tagType ~= expect and expect ~= nil then
    error(string.format("Expect tag %s (0x%02X) got %s (0x%02X)", NBT_Common.get_tag_name(expect), expect, NBT_Common.get_tag_name(tagType), tagType))
  end
  
  if tagType == NBT_Common.TAG_END then
    return NBT_Common.TAG_END, "", nil
  end
  
  local data = nil
  local name = TAG_String_read(reader)
  
  local tag_reader = tag_reader_list[tagType]
  if tag_reader == nil then
    error(string.format("Unknown tag 0x%02X", tagType))
  end
  data = tag_reader(reader)
  
  return tagType, name, data
end

tag_reader_list[NBT_Common.TAG_END] = function()error("Shouldn't be here") end 
tag_reader_list[NBT_Common.TAG_BYTE] = TAG_Byte_read 
tag_reader_list[NBT_Common.TAG_SHORT] = TAG_Short_read 
tag_reader_list[NBT_Common.TAG_INT] = TAG_Int_read  
tag_reader_list[NBT_Common.TAG_LONG] = TAG_Long_read 
tag_reader_list[NBT_Common.TAG_FLOAT] = TAG_Float_read 
tag_reader_list[NBT_Common.TAG_DOUBLE] = TAG_Double_read 
tag_reader_list[NBT_Common.TAG_BYTE_ARRAY] = TAG_ByteArray_read 
tag_reader_list[NBT_Common.TAG_STRING] = TAG_String_read 
tag_reader_list[NBT_Common.TAG_LIST] = TAG_List_read 
tag_reader_list[NBT_Common.TAG_COMPOUND] = TAG_Compound_read 

--[[
Reader signature
function <string> reader(<number> bytes_to_return) 
]]
function M.load(reader)
  assert(type(reader) == "function", "expect function at argument #1")
  local tagType = string.byte(reader(1))
  local name = TAG_String_read(reader)
  local data 
  if tagType == NBT_Common.TAG_COMPOUND then
    data = TAG_Compound_read(reader)
  else
    error(string.format("Expect tag 0x%02X got tag 0x%02X", NBT_Common.TAG_COMPOUND, tagType))
  end
  
  return {
    type = tagType,
    data = data,
  }, name
end

--Convenience wrapper to load from a filename
function M.load_filename(filename)
  assert(type(filename) == "string", "expect string at argument #1")
  
  --This where <close> useful to prevent overcomplicated function to preserve stacktrace on error AND close the file handle
  local fileHandle<close> = assert(io.open(filename, "r"))
  
  return M.load(function(numBytes)
    return assert(fileHandle:read(numBytes))
  end)
end

--Convenience wrapper to load from a FILE* handle
function M.load_file_handle(handle)
  assert(type(handle) == "userdata", "expect FILE* handle at argument #1")
  
  return M.load(function(numBytes)
    return assert(handle:read(numBytes))
  end)
end

return M





