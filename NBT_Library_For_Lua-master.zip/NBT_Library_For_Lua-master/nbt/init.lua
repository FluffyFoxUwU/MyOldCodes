if (load("return ~1")) == nil or (load("local var<close> = nil")) == nil or math.type == nil then
  error("Require Lua 5.4+ or later")
end

local nbt_reader = require("nbt.nbt_reader")
local nbt_writer = require("nbt.nbt_writer")
local NBT_Common = require("nbt.nbt_common")

local function dump(tab, depth, name)
  depth = depth or 0
  local indentString = "  "
  local indent = string.rep(indentString, depth)
  if tab.type == NBT_Common.TAG_LIST then
    print(string.format("%s'%s': %s (%s) = [", indent, tostring(name), NBT_Common.get_tag_name(tab.type), NBT_Common.get_tag_name(tab.data.type)))
  else
    print(string.format("%s'%s': %s = {", indent, tostring(name), NBT_Common.get_tag_name(tab.type)))
  end
  
  if tab.type == NBT_Common.TAG_COMPOUND then
    for k,v in pairs(tab.data) do
      if v.type == NBT_Common.TAG_COMPOUND or v.type == NBT_Common.TAG_LIST then
        dump(v, depth + 1, k)
      elseif v.type == NBT_Common.TAG_LONG then
        print(string.format("%s%s'%s' : %s = {high = %s, low = %s}", indent, indentString, k, NBT_Common.get_tag_name(v.type), tostring(v.data.high), tostring(v.data.low)))
      elseif v.type == NBT_Common.TAG_BYTE_ARRAY then
        io.write(string.format("%s%s'%s' : %s = [", indent, indentString, k, NBT_Common.get_tag_name(v.type)))
        for _, v in ipairs(v.data) do
          io.write(string.format("%d, ", v))
        end
        print("]")
      elseif v.type == NBT_Common.TAG_STRING then
        print(string.format("%s%s'%s' : %s = '%s'", indent, indentString, k, NBT_Common.get_tag_name(v.type), tostring(v.data)))
      else
        print(string.format("%s%s'%s' : %s = %s", indent, indentString, k, NBT_Common.get_tag_name(v.type), tostring(v.data)))
      end 
    end
  else
    for k,v in ipairs(tab.data) do
      if v.type == NBT_Common.TAG_COMPOUND or v.type == NBT_Common.TAG_LIST then
        dump(v, depth + 1, k)
      elseif v.type == NBT_Common.TAG_LONG then
        print(string.format("%s%s[%d] = {high = %s, low = %s} ", indent, indentString, k, tostring(v.data.high), tostring(v.data.low)))
      elseif v.type == NBT_Common.TAG_BYTE_ARRAY then
        io.write(string.format("%s%s'%s' : %s = [", indent, indentString, k, NBT_Common.get_tag_name(v.type)))
        for _, v in ipairs(v.data) do
          io.write(string.format("0x%02X, ", v))
        end
        print("]")
      elseif v.type == NBT_Common.TAG_STRING then
        print(string.format("%s%s'%s' : %s = '%s'", indent, indentString, k, NBT_Common.get_tag_name(v.type), tostring(v.data)))
      else
        print(string.format("%s%s[%d] = %s", indent, indentString, k, tostring(tab.data)))
      end
    end
  end
  
  if tab.type == NBT_Common.TAG_LIST then
    print(string.format("%s]", indent))
  else
    print(string.format("%s}", indent))
  end 
end

return {
  reader = nbt_reader,
  writer = nbt_writer,
  common = NBT_Common,
  dump = function(nbtTable, rootTagName)
    dump(nbtTable, nil, rootTagName or "")
  end,
  
  TAG_String = function(data)
    assert(type(data) == "string", "Expect string")
    assert(string.len(data) <= 32767, "String cant be larger than 32,767 bytes")
    return {
      data = data,
      type = NBT_Common.TAG_STRING
    }
  end, 
  TAG_Int = function(data)
    assert(type(data) == "number", "Expect 32-bit signed integer")
    assert(math.type(data) == "integer", "Expect 32-bit signed integer")
    assert(-2147483648 <= data and data <= 2147483647, "32-bit integer out of range (range is -2147483648 <= x <= 2147483647)")
    return {
      data = data,
      type = NBT_Common.TAG_INT 
    }
  end,
  TAG_Long = function(data)
    assert(type(data) == "table", "Expect table of two 32-bit unsigned integers (in form of {high = <higher unsigned 32-bit of long value>, low = <lower unsigned 32-bit of long value>})")
    assert(data.high < 4294967296 and data.high >= 0, "data.high is out of range (range is 0 <= x <= 4294967295)") 
    assert(data.low < 4294967296 and data.low >= 0, "data.low is out of range (range is 0 <= x <= 4294967295)") 
    return {
      data = data,
      type = NBT_Common.TAG_LONG
    }
  end,
  TAG_Byte = function(data)
    assert(type(data) == "number", "Expect 8-bit signed integer")
    assert(math.type(data) == "integer", "Expect 8-bit signed integer")
    assert(-128 <= data and data <= 127, "32-bit integer out of range (range is -128 <= x <= 127)")
    return {
      data = data,
      type = NBT_Common.TAG_BYTE
    }
  end, 
  TAG_ByteArray = function(data)
    assert(type(data) == "table", "Expect table of 8-bit signed integer")
    assert(#data <= 2147483647, "Byte array cant be larger than 2,147,483,647 bytes")
    for k,v in ipairs(data) do
      if not (-128 <= v and v <= 127) then
        error(string.format("8-bit integer at index %d have out of range value (range is -128 <= x <= 127)", k))
      end
    end
    return {
      data = data,
      type = NBT_Common.TAG_BYTE_ARRAY
    }
  end,
  TAG_Short = function(data)
    assert(type(data) == "number", "Expect 16-bit signed integer")
    assert(math.type(data) == "integer", "Expect 16-bit signed integer")
    assert(-32768 <= data and data <= 32767, "32-bit integer out of range (range is -32768 <= x <= 32767)")
    return {
      data = data,
      type = NBT_Common.TAG_SHORT
    }
  end, 
  TAG_Float = function(data)
    assert(type(data) == "number", "Expect 32-bit float")
    assert(math.type(data) == "float", "Expect 32-bit float")
    assert((-3.4028235e+38 <= data and data <= 3.4028235e+38) or (data == -(0/0) or data == 10e8888), "32-bit float out of range (range is -32768 <= x <= 32767)")
    return {
      data = data,
      type = NBT_Common.TAG_FLOAT
    }
  end, 
  TAG_Double = function(data)
    assert(type(data) == "number", "Expect 64-bit float")
    assert(math.type(data) == "float", "Expect 64-bit float")
    assert((-1.7976931348623158e+308 <= data and data <= 1.7976931348623158e+308) or (data == -(0/0) or data == 10e8888), "64-bit float out of range (range is -32768 <= x <= 32767)")
    return {
      data = data,
      type = NBT_Common.TAG_DOUBLE
    }
  end, 
  TAG_Compound = function(data)
    assert(type(data) == "table", "Expect table of tags (table must use string keys)")
    for k,v in pairs(data) do
      assert(type(k) == "string", string.format("Expect 'string' for key '%s' not '%s'", tostring(k), type(k)))
      assert(type(v) == "table", string.format("Expect table containing tag data at index '%s' got '%s' value type", tostring(k), type(v)))
    end
    return {
      data = data,
      type = NBT_Common.TAG_COMPOUND
    }
  end,
  TAG_List = function(listType, data)
    assert(type(data) == "table", "Expect table of tags of type <tag type> (table must be continous array)")
    assert(type(listType) == "number", "Expect tag ID")
    assert(NBT_Common.get_tag_name(listType) ~= "TAG_UNKNOWN", "Invalid tag ID")
    assert(listType ~= NBT_Common.TAG_END, "Expect non TAG_END tag")
    for k,v in ipairs(data) do
      assert(type(v) == "table", string.format("Expect table containing tag data at index '%s' got '%s' value type", tostring(k), type(v)))
    end
    return {
      data = data,
      type = NBT_Common.TAG_LIST
    }
  end 
}















