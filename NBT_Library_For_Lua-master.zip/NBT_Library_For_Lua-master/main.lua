#!/bin/lua5.4
local NBT = require("nbt")

--To read

--Load from filename
local data = NBT.reader.load_filename("data.dat")

--Use the specified file handler to load 
--useful for if the file have multiple seperate NBT appended to same file
--NOTE: it wont close the file handler
local f<close> = io.open("data.dat")
local data = NBT.reader.load_file_handle(f)

--Use custom reader (useful if you're not reading from file but from other place
--like sockets, pipes, etc
--Reader must take one argument that is how many bytes to read and return string
--of the reading result or throw error in failure
local f<close> = io.open("data.dat")
local data = NBT.reader.load(function(numBytes)
  return f:read(numBytes)
end)

--Accessing NBT data

--Reading Data compound from root compound
local Data = data.data["Data"]

--Reading LevelName string from Data compound 
--NOTE reading list tag is the same but uses integer index instead string
local LevelName = Data.data["LevelName"].data

--Creating empty NBT data
local nbtData = NBT.TAG_Compound({ --Creating compound tag
  name = NBT.TAG_String("Hello world") --Creating string tag
})

--To write NBT data

--Save to file at filename (overwriting it)
NBT.writer.save_to_filename("test.dat", "ROOT_TAG_NAME", nbtData)

--Use the specified file handler to save
--useful for if you want to append multiple seperate NBT to same file
--NOTE: it wont close the file handler
local f<close> = io.open("test.dat", "w")
NBT.writer.save_to_file_handle(f, "ROOT_TAG_NAME", nbtData)

--Use custom writer (useful if you're not writing to a file but from other place
--like sockets, pipes, etc
--Write must take one argument that is data to write
--or throw error in failure and no return value
local f<close> = io.open("test.dat", "w")
NBT.writer.save(function(data)
  return f:write(data)
end, "ROOT_TAG_NAME", nbtData)








