--NBT writer
local M = {}
local NBT_Common = require("nbt.nbt_common")

local function writeBig_Byte(writer, num)
  local unsignNum = num
  
  if num < 0 then
    unsignNum = ~num 
    unsignNum = unsignNum + 1
    unsignNum = unsignNum & 0xFF
  end
  
  writer(string.char(math.floor(num % 256))) 
end

local function writeBig_Short(writer, num)
  local unsignNum = num
  
  if num < 0 then
    unsignNum = ~num 
    unsignNum = unsignNum + 1
    unsignNum = unsignNum & 0xFFFF
  end
  
  writer(string.char(math.floor(num / 256 % 256))) 
  writer(string.char(math.floor(num % 256))) 
end

local function writeBig_Int(writer, num)
  local unsignNum = num
  
  if num < 0 then
    unsignNum = ~num 
    unsignNum = unsignNum + 1
    unsignNum = unsignNum & 0xFFFFFFFF 
  end
  
  writer(string.char(math.floor(num / 16777216 % 256))) 
  writer(string.char(math.floor(num / 65536 % 256))) 
  writer(string.char(math.floor(num / 256 % 256))) 
  writer(string.char(math.floor(num % 256))) 
end

local TAG_Short_write
local TAG_String_write
local TAG_Named_write
local TAG_Compound_write
local TAG_Byte_write
local TAG_Long_write
local TAG_Int_write
local TAG_List_write
local TAG_ByteArray_write

local TAG_Double_write
local TAG_Float_write

local tag_writer_list = {}

TAG_Float_write = function(writer, data)
  writer(NBT_Common.encodeFloat(data))
end

TAG_Double_write = function(writer, data)
  writer(NBT_Common.encodeDouble(data))
end

TAG_Long_write = function(writer, data)
  writeBig_Int(writer, data.high)
  writeBig_Int(writer, data.low)
end

TAG_Int_write = function(writer, data)
  writeBig_Int(writer, data)
end

TAG_Byte_write = function(writer, data)
  writeBig_Byte(writer, data)
end

TAG_ByteArray_write = function(writer, data)
  TAG_Int_write(writer, #data)
  for k,v in ipairs(data) do
    TAG_Byte_write(writer, v)
  end
end

TAG_Short_write = function(writer, data)
  writeBig_Short(writer, data)
end

TAG_String_write = function(writer, data)
  TAG_Short_write(writer, string.len(data))
  writer(data)
end

TAG_Compound_write = function(writer, data)
  for k,v in pairs(data) do
    TAG_Named_write(writer, v, k)
  end
  writer(string.char(NBT_Common.TAG_END))
end

TAG_List_write = function(writer, data)
  local tagType = data[1].type
  writer(string.char(tagType))
  TAG_Int_write(writer, #data) 
  
  if tag_writer_list[tagType] then
    tagWriter = tag_writer_list[tagType]
  else
    error(string.format("Unknown tag 0x%02X", tagType))
  end
  
  for k,v in pairs(data) do
    tagWriter(writer, v.data)
  end 
end

TAG_Named_write = function(writer, data, name)
  local tagType = data.type
  
  if tag_writer_list[tagType] then
    writer(string.char(tagType))
    TAG_String_write(writer, name)
    tag_writer_list[tagType](writer, data.data)
  else
    error(string.format("Unknown tag 0x%02X", tagType))
  end
end

tag_writer_list[NBT_Common.TAG_END] = function()error("Shouldn't be here") end 
tag_writer_list[NBT_Common.TAG_BYTE] = TAG_Byte_write
tag_writer_list[NBT_Common.TAG_SHORT] = TAG_Short_write  
tag_writer_list[NBT_Common.TAG_INT] = TAG_Int_write   
tag_writer_list[NBT_Common.TAG_LONG] = TAG_Long_write 
tag_writer_list[NBT_Common.TAG_FLOAT] = TAG_Float_write 
tag_writer_list[NBT_Common.TAG_DOUBLE] = TAG_Double_write  
tag_writer_list[NBT_Common.TAG_BYTE_ARRAY] = TAG_ByteArray_write  
tag_writer_list[NBT_Common.TAG_STRING] = TAG_String_write  
tag_writer_list[NBT_Common.TAG_LIST] = TAG_List_write 
tag_writer_list[NBT_Common.TAG_COMPOUND] = TAG_Compound_write 

--[[
Reader signature
function <string> reader(<number> bytes_to_return) 
]]
function M.save(writer, rootTagName, nbt)
  assert(type(writer) == "function", "expect function at argument #1")
  assert(type(rootTagName) == "string", "expect string at argument #2")
  assert(type(nbt) == "table", "expect table at argument #3")
  
  TAG_Named_write(writer, nbt, rootTagName)
end

--Convenience wrapper to save to a filename
function M.save_to_filename(filename, rootTagName, data)
  assert(type(filename) == "string", "expect string at argument #1")
  assert(type(rootTagName) == "string", "expect string at argument #2")
  assert(type(data) == "table", "expect table at argument #3")
  
  --This where <close> useful to prevent overcomplicated function to preserve stacktrace on error AND close the file handle
  local fileHandle<close> = assert(io.open(filename, "w"))
  local nbt = M.save(function(data)
    assert(fileHandle:write(data))
  end, rootTagName, data)
  
  fileHandle:close()
  
  return nbt
end

--Convenience wrapper to save to a FILE* handle
function M.save_to_file_handle(handle, rootTagName, data)
  assert(type(handle) == "userdata", "expect FILE* handle at argument #1")
  assert(type(rootTagName) == "string", "expect string at argument #2")
  assert(type(data) == "table", "expect table at argument #3")
  
  return M.save(function(data)
    assert(handle:write(data))
  end, rootTagName, data)
end

return M