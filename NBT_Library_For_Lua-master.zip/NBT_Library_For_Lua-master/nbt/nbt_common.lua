local M = {}

local TAG_END = 0x00
local TAG_BYTE = 0x01
local TAG_SHORT = 0x02
local TAG_INT = 0x03
local TAG_LONG = 0x04
local TAG_FLOAT = 0x05
local TAG_DOUBLE = 0x06
local TAG_BYTE_ARRAY = 0x07 --Array of literal bytes
local TAG_STRING = 0x08
local TAG_LIST = 0x09 
local TAG_COMPOUND = 0x0A

M.TAG_END = TAG_END
M.TAG_BYTE = TAG_BYTE
M.TAG_SHORT = TAG_SHORT
M.TAG_INT = TAG_INT
M.TAG_LONG = TAG_LONG
M.TAG_FLOAT = TAG_FLOAT
M.TAG_DOUBLE = TAG_DOUBLE
M.TAG_BYTE_ARRAY = TAG_BYTE_ARRAY --Array of literal bytes
M.TAG_STRING = TAG_STRING
M.TAG_LIST = TAG_LIST 
M.TAG_COMPOUND = TAG_COMPOUND

local tag_reader_name = {}
tag_reader_name[TAG_END] = "TAG_END"
tag_reader_name[TAG_BYTE] = "TAG_BYTE" 
tag_reader_name[TAG_SHORT] = "TAG_SHORT" 
tag_reader_name[TAG_INT] = "TAG_INT" 
tag_reader_name[TAG_LONG] = "TAG_LONG" 
tag_reader_name[TAG_FLOAT] = "TAG_FLOAT" 
tag_reader_name[TAG_DOUBLE] = "TAG_DOUBLE" 
tag_reader_name[TAG_BYTE_ARRAY] = "TAG_BYTE_ARRAY" 
tag_reader_name[TAG_STRING] = "TAG_STRING"
tag_reader_name[TAG_LIST] = "TAG_LIST" 
tag_reader_name[TAG_COMPOUND] = "TAG_COMPOUND" 

function M.get_tag_name(tagType)
  return tag_reader_name[tagType] or "TAG_UNKNOWN"
end

do
  --Slightly modified from https://stackoverflow.com/a/57443984/13447666
  
  --Define some commonly used constants here so we don't have to do this at runtime
  --ln(2), used for change of base down the line
  local log2 = math.log(2)

  --Used to convert the fraction into a (very large) integer
  local pow2to52 = math.pow(2,52)

  --Used for bit-shifting
  local f08 = math.pow(2, 8)
  local f16 = math.pow(2,16)
  local f24 = math.pow(2,24)
  local f32 = math.pow(2,32)
  local f40 = math.pow(2,40)
  local f48 = math.pow(2,48)
  
  local substr = string.sub
  local byte = string.byte
  
  local char = string.char 
  
  M.encodeDouble = function(number)
    --IEEE double-precision floating point number
    --Specification: https://en.wikipedia.org/wiki/Double-precision_floating-point_format

    --Separate out the sign, exponent and fraction
    local sign      = number < 0 and 1 or 0
    local exponent  = math.ceil(math.log(math.abs(number))/log2) - 1
    local fraction  = math.abs(number)/math.pow(2,exponent) - 1

    --Make sure the exponent stays in range - allowed values are -1023 through 1024
    if (exponent < -1023) then 
      --We allow this case for subnormal numbers and just clamp the exponent and re-calculate the fraction
      --without the offset of 1
      exponent = -1023
      fraction = math.abs(number)/math.pow(2,exponent)
    elseif (exponent > 1024) then
      --If the exponent ever goes above this value, something went horribly wrong and we should probably stop
      error("Exponent out of range: " .. exponent)
    end

    --Handle special cases
    if (number == 0) then
      --Zero
      exponent = -1023
      fraction = 0
    elseif (math.abs(number) == math.huge) then
      --Infinity
      exponent = 1024
      fraction = 0
    elseif (number ~= number) then
      --NaN
      exponent = 1024
      fraction = (pow2to52-1)/pow2to52
    end

    --Prepare the values for encoding
    local expOut = exponent + 1023                                  --The exponent is an 11 bit offset-binary
    local fractionOut = fraction * pow2to52                         --The fraction is 52 bit, so multiplying it by 2^52 will give us an integer


    --Combine the values into 8 bytes and return the result
    return char(
      128*sign + math.floor(expOut/16),                       --Byte 0: Sign and then shift exponent down by 4 bit
      (expOut%16)*16 + math.floor(fractionOut/f48),           --Byte 1: Shift fraction up by 4 to give most significant bits, and fraction down by 48
      math.floor(fractionOut/f40)%256,                        --Byte 2: Shift fraction down 40 bit
      math.floor(fractionOut/f32)%256,                        --Byte 3: Shift fraction down 32 bit
      math.floor(fractionOut/f24)%256,                        --Byte 4: Shift fraction down 24 bit
      math.floor(fractionOut/f16)%256,                        --Byte 5: Shift fraction down 16 bit
      math.floor(fractionOut/f08)%256,                        --Byte 6: Shift fraction down 8 bit
      math.floor(fractionOut % 256)                           --Byte 7: Last 8 bits of the fraction
    )
  end

  M.decodeDouble = function(str)
    --Get bytes from the string
    local byte0 = byte(substr(str,1,1))
    local byte1 = byte(substr(str,2,2))
    local byte2 = byte(substr(str,3,3))
    local byte3 = byte(substr(str,4,4))
    local byte4 = byte(substr(str,5,5))
    local byte5 = byte(substr(str,6,6))
    local byte6 = byte(substr(str,7,7))
    local byte7 = byte(substr(str,8,8))

    --Separate out the values
    local sign = byte0 >= 128 and 1 or 0
    local exponent = (byte0%128)*16 + math.floor(byte1/16)
    local fraction = (byte1%16)*f48 
                     + byte2*f40 + byte3*f32 + byte4*f24 
                     + byte5*f16 + byte6*f08 + byte7

    --Handle special cases
    if (exponent == 2047) then
      --Infinities
      if (fraction == 0) then return math.pow(-1,sign) * math.huge end

      --NaN
      if (fraction == pow2to52-1) then return 0/0 end
    end

    --Combine the values and return the result
    if (exponent == 0) then
      --Handle subnormal numbers
      return math.pow(-1,sign) * math.pow(2,exponent-1023) * (fraction/pow2to52)
    else
      --Handle normal numbers
      return math.pow(-1,sign) * math.pow(2,exponent-1023) * (fraction/pow2to52 + 1)
    end
  end

end

do
  -- Modified from https://github.com/ToxicFrog/vstruct/blob/b6889e3b275e9f9532b5dff4917e903b17e22730/api.lua
  
  -- turn a list of booleans into an int
  -- the converse of explode
  local function struct_implode(mask, size)
    size = size or #mask
    
    local int = 0
    for i=1,size do
      int = int + (2^(i-1) * mask[i])
    end
    return int
  end
  
  function math_trunc(n)
    if n < 0 then
      return math.ceil(n)
    else
      return math.floor(n)
    end
  end
  
  function struct_explode(int, size)
    size = size or 0
    
    local mask = {}
    while int ~= 0 or #mask < size do
      table.insert(mask, int % 2)
      int = math_trunc(int/2)
    end
    return mask
  end
  
  local function reader(data, size_exp, size_fraction)
    local fraction, exponent, sign
    size_fraction = 23
    size_exp = 8
    -- Split the unsigned integer into the 3 IEEE fields
    local bits = {} --= struct.read(endian.." m"..#data, data)[1]
    --bits expected right most bits at lower index 
    local iterator = string.gmatch(data, ".")
    local integer = string.byte(iterator()) * 16777216.0 +  
                    string.byte(iterator()) * 65536.0 +
                    string.byte(iterator()) * 256.0 +
                    string.byte(iterator())
    for i=0,31 do
      bits[#bits + 1] = integer % 2
      integer = math.floor(integer / 2)
    end
    
    local fraction = struct_implode({table.unpack(bits, 1, size_fraction)}, size_fraction)
    local exponent = struct_implode({table.unpack(bits, size_fraction+1, size_fraction+size_exp)}, size_exp)
    local sign = (bits[#bits] == 1) and -1 or 1

    -- special case: exponent is all 1s
    if exponent == 2^size_exp-1 then
      -- significand is 0? +- infinity
      if fraction == 0 then
        return sign * math.huge

      -- otherwise it's NaN
      else
        return 0/0
      end
    end

    -- restore the MSB of the significand, unless it's a subnormal number
    if exponent ~= 0 then
      fraction = fraction + (2 ^ size_fraction)
    else
      exponent = 1
    end

    -- remove the exponent bias
    exponent = exponent - 2 ^ (size_exp - 1) + 1

    -- Decrease the size of the exponent rather than make the fraction (0.5, 1]
    exponent = exponent - size_fraction

    return sign * (fraction * 2.0^exponent)
  end
  
  local function writer(value, size_exp, size_fraction)
    size_fraction = 23
    size_exp = 8
    
    local size = (size_exp + size_fraction + 1)/8
    --local endian = io("endianness", "get") == "big" and ">" or "<"
    local bias = 2^(size_exp-1)-1

    if value < 0
    or 1/value == -math.huge then -- handle the case of -0
      sign = true
      value = -value
    else
      sign = false
    end

    -- special case: value is infinite
    if value == math.huge then
      exponent = bias+1
      fraction = 0

    -- special case: value is NaN
    elseif value ~= value then
      exponent = bias+1
      fraction = 2^(size_fraction-1)

    --special case: value is 0
    elseif value == 0 then
      exponent = -bias
      fraction = 0

    else
      fraction,exponent = math.frexp(value)

      -- subnormal number
      if exponent+bias <= 1 then
        fraction = fraction * 2^(size_fraction+(exponent+bias)-1)
        exponent = -bias

      else
        -- remove the most significant bit from the fraction and adjust exponent
        fraction = fraction - 0.5
        exponent = exponent - 1

        -- turn the fraction into an integer
        fraction = fraction * 2^(size_fraction+1)
      end
    end


    -- add the exponent bias
    exponent = exponent + bias

    local bits = struct_explode(fraction)
    local bits_exp = struct_explode(exponent)
    for i=1,size_exp do
      bits[size_fraction+i] = bits_exp[i]
    end
    bits[size_fraction+size_exp+1] = sign

    --return struct.write(endian.."m"..size, {bits})
    local tmp = {}
    for i=1,32 do
      if bits[i] == nil then
        bits[i] = 0
      elseif bits[i] == true then
        bits[i] = 1
      elseif bits[i] == false then
        bits[i] = 0
      end
      tmp[i] = tostring(math.floor(bits[i]))
    end
    
    local integer = tonumber(string.reverse(table.concat(tmp)), 2) 
    local tmp = string.char(math.floor(integer / 16777216) % 256)..
                string.char(math.floor(integer / 65536) % 256)..
                string.char(math.floor(integer / 256) % 256).. 
                string.char(integer % 256)
    return tmp
  end

  
  M.decodeFloat = function(data)
    return reader(data)
  end
  
  M.encodeFloat = function(data)
    return writer(data)
  end
end

return M















